## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/mastering-immutable-js/9781788395113)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1788395115).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Mastering-Immutablejs
Mastering Immutable.js by Packt

## Installation
Make sure [Node.js](https://nodejs.org/) is installed. Then, clone this
repository:
```bash
git clone https://github.com/PacktPublishing/Mastering-Immutablejs.git
```

Change directories and install:
```bash
cd Mastering-Immutablejs
npm install
```

## Running examples
Since the code examples use `import`, you need to compile the source before
running it. The easiest way to do this is compiling it on-the-fly using
`babel-node`:
```bash
npm run babel-node 02/01-available-types.js
```

Chapters 14 and 16 have examples that only work in the browser. For these,
you can just open up the HTML files in these directories right in the browser.
